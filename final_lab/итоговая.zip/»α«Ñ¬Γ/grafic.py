import matplotlib.pyplot as plt

butter_move = [19.66, 53.91, 60.56]
cheese_move = [9.79, 17.91, 17.62]
milk_move = [48.05, 72.93, 79.82]
curd_move = [26.11, 34.45, 51.02]
margarine_move = [35.47, 27.37, 43.89]
meat_move = [21.34, 54.4, 80.12]
sausage_move = [25.97, 54.99, 73.35]
stuffing_move = [20.25, 63.21, 66.66]
bone_move = [7.89, 17.66, 19.73]
total = ["На початку місяця", "Вибуток", "Прибуток"]

plt.plot(total, butter_move, label = "Масло")
plt.plot(total, cheese_move, label = "Сир твердий")
plt.plot(total, milk_move, label = "Молоко")
plt.plot(total, curd_move, label = "Сир")
plt.plot(total, margarine_move, label = "Маргарин")
plt.plot(total, meat_move, label = "М'ясо")
plt.plot(total, sausage_move, label = "Ковбаса")
plt.plot(total, stuffing_move, label = "Фарш м'ясний")
plt.plot(total, bone_move, label = "М'ясо кістки")
plt.ylabel("Кількість")
plt.legend()
plt.grid(True)

def showplot():
    plt.show()