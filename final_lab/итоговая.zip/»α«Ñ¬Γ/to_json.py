import json
from tovar import nounlist2
from move import nounlist1

def convertToJSON():
    with open("c:/Users/UA/Desktop/итоговая кн/tovar_json.json", "w") as write_file:
        json.dump(nounlist1, write_file)
def convertInJSON():
    with open("c:/Users/UA/Desktop/итоговая кн/move_json.json", "w") as write_file:
        json.dump(nounlist2, write_file)